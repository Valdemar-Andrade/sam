package com.ucan.sam.controllers;


import com.ucan.sam.entities.DTO.TopicoDTO;
import com.ucan.sam.entities.Topico;
import com.ucan.sam.entities.Usuario;
import com.ucan.sam.mapper.TopicoMapper;
import com.ucan.sam.security.AuthUtil;
import com.ucan.sam.services.TopicoService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/topico")
public class TopicoController
{
    @Autowired
    private TopicoService topicoService;
    @Autowired
    private TopicoMapper topicoMapper;

    @PostMapping
    public ResponseEntity<?> criarTopico(@RequestBody TopicoDTO topicoDTO, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Topico> topicoSalvo = topicoService.criarTopico(topicoDTO);

            if (topicoSalvo.isPresent())
                return ResponseEntity.ok(topicoMapper.toDTO(topicoSalvo.get()));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erro ao criar o Topico!");
        }else {
            return auth;
        }
    }

    @GetMapping
    public ResponseEntity<?> findAll(HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            List<Topico> topicos = topicoService.findAll();

            if (topicos.isEmpty())
                ResponseEntity.noContent().build();
            return ResponseEntity.ok(topicoMapper.toDTO(topicos));
        }else {
            return auth;
        }
    }

    @GetMapping("/{pk}")
    public ResponseEntity<?> findByPk(@PathVariable Integer pk, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Topico> topico = topicoService.findByPk(pk);

            if (topico.isPresent()){
                return ResponseEntity.ok(topicoMapper.toDTO(topico.get()));
            }else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Tópico não encontrado!");
            }
        }else {
            return auth;
        }
    }

    @PutMapping
    public ResponseEntity<?> updateTopico(@RequestBody TopicoDTO topicoDTO, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Topico> topicoAtualizado = topicoService.updateTopico(topicoDTO);

            if (topicoAtualizado.isPresent()){
                return ResponseEntity.ok(topicoMapper.toDTO(topicoAtualizado.get()));
            }else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Tópico não encontrado!");
            }
        }else {
            return auth;
        }
    }

    @DeleteMapping("/{pk}")
    public ResponseEntity<?> deleteTopico(@PathVariable Integer pk, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            if (topicoService.deleteTopico(pk)){
                return ResponseEntity.ok("Tópico Deletado com sucesso!");
            }else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Tópico não encontrado!");
            }
        }else {
            return auth;
        }
    }
}
