package com.ucan.sam.security;

import com.ucan.sam.entities.Usuario;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/auth")
public class AuthController
{
    @Autowired
    AuthUser authUser;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest, HttpSession session){
        if (authUser.authUserLogin(loginRequest, session)){
            return ResponseEntity.ok("Login realizado com sucesso!");
        }else {
            return ResponseEntity.badRequest().body("Email ou senha inválidos.");
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpSession session){
        authUser.logout(session);
        return ResponseEntity.ok("Logout realizado com sucesso.");
    }

    @GetMapping("loggedin")
    public ResponseEntity<?> usuarioLogado(HttpSession session){
        Optional<Usuario> usuarioLogado = authUser.loggedIn(session);
        if (usuarioLogado.isPresent()){
            return ResponseEntity.ok("O usuário Logado no momento: " + usuarioLogado.get().getFkPessoa().getNome());
        }else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Nenhum usuário está Logado!");
        }
    }

}
