package com.ucan.sam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication
public class SamApplication
{
    public static void main(String[] args)
    {
        SpringApplication.run(SamApplication.class, args);
    }
}
