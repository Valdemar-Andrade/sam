package com.ucan.sam.mensageria;

import com.ucan.sam.entities.Campanha;
import com.ucan.sam.entities.DTO.CampanhaDTO;
import com.ucan.sam.services.MensagemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class MensagemListener
{
    @Autowired
    private MensagemService mensagemService;

    @KafkaListener(topics = "campanhas", groupId = "grupo-sam")
    public void processarMensagens(CampanhaDTO campanhaDTO) {
        System.out.println("Processando campanha (Listener): " + campanhaDTO.getTitulo());
        Optional<Campanha> campanha = mensagemService.getCampanhaEntityByDTO(campanhaDTO);

        if (campanha.isPresent()){
            // processa as mensagens da Campanha e os envia a cada Lead relacionado aos Topicos da Campanha
            mensagemService.processarMensagensPorCampanha(campanha.get());
        }
    }
}
