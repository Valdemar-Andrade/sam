package com.ucan.sam.entities.DTO;

import java.time.LocalDateTime;
import java.util.List;

public class CampanhaDTO
{
    private Integer pkCampanha;
    private String titulo;
    private String descricao;
    private LocalDateTime dataEnvio;
    private Integer status;
    private Integer fkEmpresa;
    private List<Integer> topicosRelacionados;
    private Integer fkUsuario;

    public Integer getPkCampanha()
    {
        return pkCampanha;
    }

    public void setPkCampanha(Integer pkCampanha)
    {
        this.pkCampanha = pkCampanha;
    }

    public String getTitulo()
    {
        return titulo;
    }

    public void setTitulo(String titulo)
    {
        this.titulo = titulo;
    }

    public String getDescricao()
    {
        return descricao;
    }

    public void setDescricao(String descricao)
    {
        this.descricao = descricao;
    }

    public LocalDateTime getDataEnvio()
    {
        return dataEnvio;
    }

    public void setDataEnvio(LocalDateTime dataEnvio)
    {
        this.dataEnvio = dataEnvio;
    }

    public Integer getStatus()
    {
        return status;
    }

    public void setStatus(Integer status)
    {
        this.status = status;
    }

    public Integer getFkEmpresa()
    {
        return fkEmpresa;
    }

    public void setFkEmpresa(Integer fkEmpresa)
    {
        this.fkEmpresa = fkEmpresa;
    }

    public List<Integer> getTopicosRelacionados()
    {
        return topicosRelacionados;
    }

    public void setTopicosRelacionados(List<Integer> topicosRelacionados)
    {
        this.topicosRelacionados = topicosRelacionados;
    }

    public Integer getFkUsuario()
    {
        return fkUsuario;
    }

    public void setFkUsuario(Integer fkUsuario)
    {
        this.fkUsuario = fkUsuario;
    }
}
