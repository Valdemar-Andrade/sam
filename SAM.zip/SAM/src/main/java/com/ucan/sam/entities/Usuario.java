package com.ucan.sam.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ucan.sam.converter.TipoUsuarioConverter;
import com.ucan.sam.converter.TipoUsuarioDeserializer;
import com.ucan.sam.entities.DTO.UsuarioDTO;
import com.ucan.sam.enums.TipoUsuario;
import jakarta.persistence.*;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "usuario")
public class Usuario implements Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pkUsuario;

    @OneToOne
    private Pessoa fkPessoa;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String senha;

    @JsonDeserialize(using = TipoUsuarioDeserializer.class)
    @Convert(converter = TipoUsuarioConverter.class)
    private TipoUsuario tipo;

    @ManyToOne
    private Empresa fkEmpresa;

    @OneToMany(cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Campanha> campanhas;

    public Usuario(UsuarioDTO usuarioDTO){
        BeanUtils.copyProperties(usuarioDTO, this);
    }

    public Usuario(){

    }

    public Integer getPkUsuario()
    {
        return pkUsuario;
    }

    public void setPkUsuario(Integer pkUsuario)
    {
        this.pkUsuario = pkUsuario;
    }

    public Pessoa getFkPessoa()
    {
        return fkPessoa;
    }

    public void setFkPessoa(Pessoa fkPessoa)
    {
        this.fkPessoa = fkPessoa;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getSenha()
    {
        return senha;
    }

    public void setSenha(String senha)
    {
        this.senha = senha;
    }

    public TipoUsuario getTipo()
    {
        return tipo;
    }

    public void setTipo(TipoUsuario tipo)
    {
        this.tipo = tipo;
    }

    public Empresa getFkEmpresa()
    {
        return fkEmpresa;
    }

    public void setFkEmpresa(Empresa fkEmpresa)
    {
        this.fkEmpresa = fkEmpresa;
    }

    public List<Campanha> getCampanhas()
    {
        return campanhas;
    }

    public void setCampanhas(List<Campanha> campanhas)
    {
        this.campanhas = campanhas;
    }
}
