package com.ucan.sam.controllers;

import com.ucan.sam.entities.Log;
import com.ucan.sam.services.LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController("/logs")
public class LogController
{
    @Autowired
    LogService logService;

    @GetMapping
    public ResponseEntity<?> findAll(){
        List<Log> logs = logService.findAll();
        if (logs.isEmpty())
            return ResponseEntity.noContent().build();
        return ResponseEntity.ok(logs);
    }
    
}
