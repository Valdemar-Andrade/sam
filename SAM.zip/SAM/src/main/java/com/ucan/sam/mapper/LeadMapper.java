package com.ucan.sam.mapper;

import com.ucan.sam.entities.*;
import com.ucan.sam.entities.DTO.LeadDTO;
import com.ucan.sam.enums.Sexo;
import com.ucan.sam.repositories.EmpresaRepository;
import com.ucan.sam.repositories.LocalidadeRepository;
import com.ucan.sam.services.LeadService;
import com.ucan.sam.services.TopicoService;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class LeadMapper
{
    private final EmpresaRepository empresaRepository;
    private final LocalidadeRepository localidadeRepository;
    private final LeadService leadService;
    private final TopicoService topicoService;

    public LeadMapper(EmpresaRepository empresaRepository, LocalidadeRepository localidadeRepository, LeadService leadService, TopicoService topicoService)
    {
        this.empresaRepository = empresaRepository;
        this.localidadeRepository = localidadeRepository;
        this.leadService = leadService;
        this.topicoService = topicoService;
    }

    public Optional<Lead> toEntity(LeadDTO leadDTO){
        Optional<Empresa> empresa = empresaRepository.findById(leadDTO.getFkEmpresa());
        Optional<Localidade> localidade = localidadeRepository.findById(leadDTO.getFkLocalidade());

        if (empresa.isPresent() && localidade.isPresent()){
            Contacto contacto = new Contacto();
            contacto.setEmail(leadDTO.getEmail());
            contacto.setTelefone(leadDTO.getTelefone());

            Pessoa pessoa = new Pessoa();
            pessoa.setFkContacto(contacto);
            pessoa.setNome(leadDTO.getNome());
            pessoa.setSexo(Sexo.fromValor(leadDTO.getSexo()));
            pessoa.setFkLocalidade(localidade.get());

            Lead lead = new Lead();
            lead.setFkEmpresa(List.of(empresa.get()));
            lead.setFkPessoa(pessoa);
            lead.setTopicosInteresse(topicoService.getEntityByPkList(leadDTO.getTopicosInteresse()));

            return Optional.of(lead);
        }else {
            return Optional.empty();
        }
    }

    public LeadDTO toDTO(Lead lead){
        LeadDTO leadDTO = new LeadDTO();

        leadDTO.setPkLead(lead.getPkLead());
        leadDTO.setNome(lead.getFkPessoa().getNome());
        leadDTO.setEmail(lead.getFkPessoa().getFkContacto().getEmail());
        leadDTO.setTelefone(lead.getFkPessoa().getFkContacto().getTelefone());
        leadDTO.setSexo(lead.getFkPessoa().getSexo().getValor());
        leadDTO.setFkEmpresa(lead.getFkEmpresa().get(0).getPkEmpresa());
        leadDTO.setFkLocalidade(lead.getFkPessoa().getFkLocalidade().getPkLocalidade());
        leadDTO.setTopicosInteresse(topicoService.getPkByEntityList(lead.getTopicosInteresse()));

        return leadDTO;
    }
}
