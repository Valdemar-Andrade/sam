package com.ucan.sam.mapper;

import com.ucan.sam.entities.DTO.LogDTO;
import com.ucan.sam.entities.Log;
import org.springframework.stereotype.Component;

@Component
public class LogMapper
{
    public Log toEntity(LogDTO logDTO){
        Log log = new Log();
        log.setPkLog(logDTO.getPkLog());
        log.setMensagem(logDTO.getMensagem());
        log.setData(logDTO.getData());
        return log;
    }

    public LogDTO toDTO(Log log){
        LogDTO logDTO = new LogDTO();
        logDTO.setPkLog(log.getPkLog());
        logDTO.setMensagem(log.getMensagem());
        logDTO.setData(log.getData());
        return logDTO;
    }
}
