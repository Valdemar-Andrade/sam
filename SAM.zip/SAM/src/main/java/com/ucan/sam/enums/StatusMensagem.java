package com.ucan.sam.enums;

public enum StatusMensagem {
    ENVIADO(1),
    ENTREGUE(2),
    FALHOU(3);

    private final int valor;


    StatusMensagem(int valor)
    {
        this.valor = valor;
    }

    public int getValor() {
        return valor;
    }

    public static StatusMensagem fromValor(int valor){
        for (StatusMensagem statusMensagem : StatusMensagem.values()){
            if (statusMensagem.getValor() == valor){
                return statusMensagem;
            }
        }
        throw new IllegalArgumentException("Valor inválido para StatusMensagem: " + valor);
    }
}
