package com.ucan.sam.repositories;

import com.ucan.sam.entities.Mensagem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MensagemRepository extends JpaRepository<Mensagem, Integer>
{
    List<Mensagem> findByFkCampanha_PkCampanha(Integer campanhaPk);
}
