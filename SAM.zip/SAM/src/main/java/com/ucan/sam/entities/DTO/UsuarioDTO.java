package com.ucan.sam.entities.DTO;

import com.ucan.sam.entities.Usuario;
import org.springframework.beans.BeanUtils;

public class UsuarioDTO
{
    private Integer pkUsuario;
    private String nome;
    private String email;
    private String senha;
    private Integer tipo;
    private Integer sexo;
    private String telefone;
    private Integer fkLocalidade;
    private Integer fkEmpresa;

    public UsuarioDTO(Usuario usuario){
        BeanUtils.copyProperties(usuario, this);
    }

    public UsuarioDTO(){

    }

    public Integer getPkUsuario()
    {
        return pkUsuario;
    }

    public void setPkUsuario(Integer pkUsuario)
    {
        this.pkUsuario = pkUsuario;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getSenha()
    {
        return senha;
    }

    public void setSenha(String senha)
    {
        this.senha = senha;
    }

    public Integer getTipo()
    {
        return tipo;
    }

    public void setTipo(Integer tipo)
    {
        this.tipo = tipo;
    }

    public Integer getSexo()
    {
        return sexo;
    }

    public void setSexo(Integer sexo)
    {
        this.sexo = sexo;
    }

    public String getTelefone()
    {
        return telefone;
    }

    public void setTelefone(String telefone)
    {
        this.telefone = telefone;
    }

    public Integer getFkLocalidade()
    {
        return fkLocalidade;
    }

    public void setFkLocalidade(Integer fkLocalidade)
    {
        this.fkLocalidade = fkLocalidade;
    }

    public Integer getFkEmpresa()
    {
        return fkEmpresa;
    }

    public void setFkEmpresa(Integer fkEmpresa)
    {
        this.fkEmpresa = fkEmpresa;
    }
}
