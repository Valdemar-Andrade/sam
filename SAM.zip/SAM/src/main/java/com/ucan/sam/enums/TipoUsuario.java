package com.ucan.sam.enums;

public enum TipoUsuario
{
    ADMINISTRADOR(1),
    USUARIO_FINAL(2);

    private final int valor;


    TipoUsuario(int valor)
    {
        this.valor = valor;
    }

    public int getValor() {
        return valor;
    }

    public static TipoUsuario fromValor(int valor){
        for (TipoUsuario tipoUsuario : TipoUsuario.values()){
            if (tipoUsuario.getValor() == valor){
                return tipoUsuario;
            }
        }
        throw new IllegalArgumentException("Valor inválido para TipoUsuario: " + valor);
    }
}

