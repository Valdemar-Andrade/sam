package com.ucan.sam.entities.DTO;

import java.time.LocalDateTime;

public class LogDTO
{
    private Integer pkLog;
    private String mensagem;
    private LocalDateTime data;

    public Integer getPkLog()
    {
        return pkLog;
    }

    public void setPkLog(Integer pkLog)
    {
        this.pkLog = pkLog;
    }

    public String getMensagem()
    {
        return mensagem;
    }

    public void setMensagem(String mensagem)
    {
        this.mensagem = mensagem;
    }

    public LocalDateTime getData()
    {
        return data;
    }

    public void setData(LocalDateTime data)
    {
        this.data = data;
    }
}
