package com.ucan.sam.entities;

import com.ucan.sam.enums.StatusMensagem;
import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "mensagem")
public class Mensagem implements Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pkMensagem;

    @Column(nullable = false)
    @Enumerated(EnumType.ORDINAL)
    private StatusMensagem status;

    @Column(nullable = false)
    private LocalDateTime dataEnvio;

    @ManyToOne
    private Campanha fkCampanha;

    @ManyToOne
    private Lead fkLead;

    public Integer getPkMensagem()
    {
        return pkMensagem;
    }

    public void setPkMensagem(Integer pkMensagem)
    {
        this.pkMensagem = pkMensagem;
    }

    public StatusMensagem getStatus()
    {
        return status;
    }

    public void setStatus(StatusMensagem status)
    {
        this.status = status;
    }

    public LocalDateTime getDataEnvio()
    {
        return dataEnvio;
    }

    public void setDataEnvio(LocalDateTime dataEnvio)
    {
        this.dataEnvio = dataEnvio;
    }

    public Campanha getFkCampanha()
    {
        return fkCampanha;
    }

    public void setFkCampanha(Campanha fkCampanha)
    {
        this.fkCampanha = fkCampanha;
    }

    public Lead getFkLead()
    {
        return fkLead;
    }

    public void setFkLead(Lead fkLead)
    {
        this.fkLead = fkLead;
    }
}
