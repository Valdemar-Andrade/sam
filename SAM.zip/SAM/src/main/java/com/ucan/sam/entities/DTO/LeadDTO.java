package com.ucan.sam.entities.DTO;

import com.ucan.sam.entities.Lead;
import org.springframework.beans.BeanUtils;

import java.util.List;

public class LeadDTO {
    private Integer pkLead;
    private String nome;
    private String email;
    private String telefone;
    private Integer sexo;
    private List<Integer> topicosInteresse;
    private Integer fkEmpresa;
    private Integer fkLocalidade;

    public LeadDTO(Lead lead)
    {
        BeanUtils.copyProperties(lead, this);
    }

    public LeadDTO()
    {
    }

    public Integer getPkLead()
    {
        return pkLead;
    }

    public void setPkLead(Integer pkLead)
    {
        this.pkLead = pkLead;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getTelefone()
    {
        return telefone;
    }

    public void setTelefone(String telefone)
    {
        this.telefone = telefone;
    }

    public Integer getSexo()
    {
        return sexo;
    }

    public void setSexo(Integer sexo)
    {
        this.sexo = sexo;
    }

    public List<Integer> getTopicosInteresse()
    {
        return topicosInteresse;
    }

    public void setTopicosInteresse(List<Integer> topicosInteresse)
    {
        this.topicosInteresse = topicosInteresse;
    }

    public Integer getFkEmpresa()
    {
        return fkEmpresa;
    }

    public void setFkEmpresa(Integer fkEmpresa)
    {
        this.fkEmpresa = fkEmpresa;
    }

    public Integer getFkLocalidade()
    {
        return fkLocalidade;
    }

    public void setFkLocalidade(Integer fkLocalidade)
    {
        this.fkLocalidade = fkLocalidade;
    }
}
