package com.ucan.sam.services;

import com.ucan.sam.entities.Contacto;
import com.ucan.sam.repositories.ContactoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ContactoService
{
    @Autowired
    private ContactoRepository contactoRepository;

    public Contacto cadastrarContacto(Contacto contacto){
        return contactoRepository.save(contacto);
    }
}
