package com.ucan.sam.controllers;

import com.ucan.sam.entities.DTO.LeadDTO;
import com.ucan.sam.entities.Lead;
import com.ucan.sam.entities.Usuario;
import com.ucan.sam.mapper.LeadMapper;
import com.ucan.sam.repositories.UsuarioRepository;
import com.ucan.sam.security.AuthUtil;
import com.ucan.sam.services.LeadService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/lead")
public class LeadController
{
    @Autowired
    private LeadService leadService;
    @Autowired
    private LeadMapper leadMapper;
    @Autowired
    private UsuarioRepository usuarioRepository;

    @PostMapping
    public ResponseEntity<?> criarLead(@RequestBody LeadDTO leadDTO, HttpSession session) {
        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Lead> novoLead = leadService.criarLead(leadDTO);

            if (novoLead.isPresent()){
                return ResponseEntity.ok(leadMapper.toDTO(novoLead.get()));
            }
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erro ao criar o Lead!");
        }else {
            return auth;
        }
    }

    @PostMapping("/upload")
    public ResponseEntity<?> carregarClientes(@RequestParam("file") MultipartFile file, HttpSession session) {
        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);

        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
            Optional<Usuario> usuario = usuarioRepository.findById(usuarioLogado.getPkUsuario());
            Integer empresaPk = usuario.get().getFkEmpresa().getPkEmpresa();

            if (leadService.processarExcel(file, empresaPk)){
                return ResponseEntity.ok("Arquivo XLS processado com sucesso!");
            }else {
                return ResponseEntity.badRequest().body("Erro ao processar arquivo: ");
            }
        }else {
            return auth;
        }
    }

    @GetMapping
    public ResponseEntity<?> listarLeads(HttpSession session) {
        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            List<Lead> leads = leadService.listarLeads();
            List<LeadDTO> leadsDTO = new ArrayList<>();
            if (leads.isEmpty()){
                return ResponseEntity.noContent().build();
            }else {
                for (Lead lead : leads){
                    leadsDTO.add(leadMapper.toDTO(lead));
                }
                return ResponseEntity.ok(leadsDTO);
            }

        }else {
            return auth;
        }
    }

    @GetMapping("/{pk}")
    public ResponseEntity<?> findByPk(@PathVariable Integer pk, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Lead> lead = leadService.findByPk(pk);

            if (lead.isPresent())
                return ResponseEntity.ok(leadMapper.toDTO(lead.get()));
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Lead não encontrado!");
        }else {
            return auth;
        }
    }

    @PutMapping
    public ResponseEntity<?> updateLead(@RequestBody LeadDTO leadDTO, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Lead> leadAtualizado = leadService.updateLead(leadDTO);
            if (leadAtualizado.isPresent()){
                return ResponseEntity.ok(leadMapper.toDTO(leadAtualizado.get()));
            }else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Lead não encontrado!");
            }
        }else {
            return auth;
        }
    }

    @DeleteMapping("/{pk}")
    public ResponseEntity<?> deleteLead(@PathVariable Integer pk, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Lead> lead = leadService.delete(pk);
            if (lead.isPresent()){
                return ResponseEntity.ok("Lead Deletado com sucesso!");
            }else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Lead não encontrado!");
            }
        }else {
            return auth;
        }
    }
}
