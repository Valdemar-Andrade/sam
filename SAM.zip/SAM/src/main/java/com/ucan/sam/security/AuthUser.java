package com.ucan.sam.security;

import com.ucan.sam.entities.Usuario;
import com.ucan.sam.repositories.UsuarioRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class AuthUser
{
    @Autowired
    UsuarioRepository usuarioRepository;

    public boolean authUserLogin(LoginRequest loginRequest, HttpSession session){
        Usuario usuario = usuarioRepository.findByEmail(loginRequest.getEmail());

        if (usuario == null || !usuario.getSenha().equals(loginRequest.getSenha())) {
            return false;
        }

        // Armazena o usuário na sessão
        session.setAttribute("usuarioLogado", usuario);
        return true;
    }

    public void logout(HttpSession session){
        session.invalidate();
    }

    public Optional<Usuario> loggedIn(HttpSession session){
        Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
        if (usuarioLogado != null){
            return Optional.of(usuarioLogado);
        }else {
            return Optional.empty();
        }
    }
}
