package com.ucan.sam.repositories;

import com.ucan.sam.entities.Topico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TopicoRepository extends JpaRepository<Topico, Integer>
{
    Optional<Topico> findByNome(String nome);
}
