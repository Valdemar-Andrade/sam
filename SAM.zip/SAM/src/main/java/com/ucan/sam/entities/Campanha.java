package com.ucan.sam.entities;

import com.ucan.sam.enums.StatusCampanha;
import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "campanha")
public class Campanha implements Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pkCampanha;

    @Column(nullable = false)
    private String titulo;

    @Column(nullable = false)
    private String descricao;

    @Column(nullable = false)
    private LocalDateTime dataEnvio;

    @Column(nullable = false)
    @Enumerated(EnumType.ORDINAL)
    private StatusCampanha status;

    @ManyToOne
    private Usuario fkUsuario;

    @ManyToOne
    private Empresa fkEmpresa;

    @ManyToMany
    private List<Topico> topicosRelacionados;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Mensagem> mensagens;

    public Integer getPkCampanha()
    {
        return pkCampanha;
    }

    public void setPkCampanha(Integer pkCampanha)
    {
        this.pkCampanha = pkCampanha;
    }

    public String getTitulo()
    {
        return titulo;
    }

    public void setTitulo(String titulo)
    {
        this.titulo = titulo;
    }

    public String getDescricao()
    {
        return descricao;
    }

    public void setDescricao(String descricao)
    {
        this.descricao = descricao;
    }

    public LocalDateTime getDataEnvio()
    {
        return dataEnvio;
    }

    public void setDataEnvio(LocalDateTime dataEnvio)
    {
        this.dataEnvio = dataEnvio;
    }

    public StatusCampanha getStatus()
    {
        return status;
    }

    public void setStatus(StatusCampanha status)
    {
        this.status = status;
    }

    public Usuario getFkUsuario()
    {
        return fkUsuario;
    }

    public void setFkUsuario(Usuario fkUsuario)
    {
        this.fkUsuario = fkUsuario;
    }

    public Empresa getFkEmpresa()
    {
        return fkEmpresa;
    }

    public void setFkEmpresa(Empresa fkEmpresa)
    {
        this.fkEmpresa = fkEmpresa;
    }

    public List<Topico> getTopicosRelacionados()
    {
        return topicosRelacionados;
    }

    public void setTopicosRelacionados(List<Topico> topicos)
    {
        this.topicosRelacionados = topicos;
    }

    public List<Mensagem> getMensagens()
    {
        return mensagens;
    }

    public void setMensagens(List<Mensagem> mensagens)
    {
        this.mensagens = mensagens;
    }
}
