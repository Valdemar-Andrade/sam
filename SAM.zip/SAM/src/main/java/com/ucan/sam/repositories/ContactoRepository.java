package com.ucan.sam.repositories;

import com.ucan.sam.entities.Contacto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ContactoRepository extends JpaRepository<Contacto, Integer>
{
    Optional<Contacto> findContactoByTelefone(String telefone);
}
