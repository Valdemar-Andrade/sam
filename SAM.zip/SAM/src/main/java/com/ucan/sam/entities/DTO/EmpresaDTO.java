package com.ucan.sam.entities.DTO;

import com.ucan.sam.entities.Empresa;
import org.springframework.beans.BeanUtils;

import java.time.LocalDate;

public class EmpresaDTO
{
    private Integer pkEmpresa;
    private String nome;
    private String email;
    private String telefone;
    private Integer fkLocalidade;
    private LocalDate dataCadastro;

    public EmpresaDTO(Empresa empresa){
        BeanUtils.copyProperties(empresa, this);
    }

    public EmpresaDTO()
    {
    }

    public Integer getPkEmpresa()
    {
        return pkEmpresa;
    }

    public void setPkEmpresa(Integer pkEmpresa)
    {
        this.pkEmpresa = pkEmpresa;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getTelefone()
    {
        return telefone;
    }

    public void setTelefone(String telefone)
    {
        this.telefone = telefone;
    }

    public Integer getFkLocalidade()
    {
        return fkLocalidade;
    }

    public void setFkLocalidade(Integer fkLocalidade)
    {
        this.fkLocalidade = fkLocalidade;
    }

    public LocalDate getDataCadastro()
    {
        return dataCadastro;
    }

    public void setDataCadastro(LocalDate dataCadastro)
    {
        this.dataCadastro = dataCadastro;
    }
}
