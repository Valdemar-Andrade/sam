package com.ucan.sam.mapper;

import com.ucan.sam.entities.DTO.TopicoDTO;
import com.ucan.sam.entities.Topico;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class TopicoMapper
{
    public Topico toEntity(TopicoDTO topicoDTO){
        Topico topico = new Topico();
        topico.setNome(topicoDTO.getNome());
        topico.setDescricao(topicoDTO.getDescricao());

        return topico;
    }

    public TopicoDTO toDTO(Topico topico){
        TopicoDTO topicoDTO = new TopicoDTO();
        topicoDTO.setPkTopico(topico.getPkTopico());
        topicoDTO.setNome(topico.getNome());
        topicoDTO.setDescricao(topico.getDescricao());

        return topicoDTO;
    }

    public List<TopicoDTO> toDTO(List<Topico> topicos){
        List<TopicoDTO> topicosDTO = new ArrayList<>();

        for (Topico t : topicos){
            topicosDTO.add(this.toDTO(t));
        }
        return topicosDTO;
    }
}
