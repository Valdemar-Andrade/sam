package com.ucan.sam.services;

import com.ucan.sam.entities.*;
import com.ucan.sam.entities.DTO.UsuarioDTO;
import com.ucan.sam.enums.Sexo;
import com.ucan.sam.enums.TipoUsuario;
import com.ucan.sam.mapper.EmpresaMapper;
import com.ucan.sam.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService
{
    @Autowired
    UsuarioRepository usuarioRepository;

    @Autowired
    private ContactoService contactoService;

    @Autowired
    private LocalidadeRepository localidadeRepository;

    @Autowired
    private PessoaService pessoaService;

    @Autowired
    private EmpresaMapper empresaMapper;

    @Autowired
    private EmpresaRepository empresaRepository;
    @Autowired
    private ContactoRepository contactoRepository;
    @Autowired
    private PessoaRepository pessoaRepository;

    public Optional<Usuario> criarUsuario(UsuarioDTO usuarioDTO)
    {
        Contacto contacto = new Contacto();
        contacto.setTelefone(usuarioDTO.getTelefone());
        contacto.setEmail(usuarioDTO.getEmail());
        Contacto contactoSalvo = contactoService.cadastrarContacto(contacto);
        Optional<Localidade> localidade = localidadeRepository.findById(usuarioDTO.getFkLocalidade());
        Optional<Empresa> empresa = empresaRepository.findById(usuarioDTO.getFkEmpresa());

        if (empresa.isPresent() && localidade.isPresent()){
            Pessoa pessoa = new Pessoa();
            pessoa.setNome(usuarioDTO.getNome());
            pessoa.setSexo(Sexo.fromValor(usuarioDTO.getSexo()));
            pessoa.setFkContacto(contactoSalvo);
            pessoa.setFkLocalidade(localidade.get());

            Pessoa pessoaSalva = pessoaService.cadastrarPessoa(pessoa);

            Usuario usuario = new Usuario();
            usuario.setFkPessoa(pessoaSalva);
            usuario.setSenha(usuarioDTO.getSenha());
            usuario.setEmail(usuarioDTO.getEmail());
            usuario.setTipo(TipoUsuario.fromValor(usuarioDTO.getTipo()));
            usuario.setFkEmpresa(empresa.get());

            return Optional.of(usuarioRepository.save(usuario));
        }
        return Optional.empty();
    }

    public List<Usuario> findAll()
    {
        return usuarioRepository.findAll();
    }

    public Optional<Usuario> findByPk(Integer pk)
    {
        return usuarioRepository.findById(pk);
    }

    public Optional<Usuario> updateUsuario(UsuarioDTO usuarioDTO)
    {
        Optional<Usuario> usuario = usuarioRepository.findById(usuarioDTO.getPkUsuario());
        Optional<Localidade> localidade = localidadeRepository.findById(usuarioDTO.getFkLocalidade());
        Optional<Empresa> empresa = empresaRepository.findById(usuarioDTO.getFkEmpresa());

        if (usuario.isPresent() && localidade.isPresent() && empresa.isPresent()){
            Contacto contacto = usuario.get().getFkPessoa().getFkContacto();
            contacto.setEmail(usuarioDTO.getEmail());
            contacto.setTelefone(usuarioDTO.getTelefone());
            Contacto contactoSalvo = contactoRepository.save(contacto);

            Pessoa pessoa = usuario.get().getFkPessoa();
            pessoa.setNome(usuarioDTO.getNome());
            pessoa.setSexo(Sexo.fromValor(usuarioDTO.getSexo()));
            pessoa.setFkLocalidade(localidade.get());
            pessoa.setFkContacto(contactoSalvo);
            Pessoa pessoaSalva = pessoaRepository.save(pessoa);

            usuario.get().setFkPessoa(pessoaSalva);
            usuario.get().setEmail(usuarioDTO.getEmail());
            usuario.get().setSenha(usuarioDTO.getSenha());
            usuario.get().setTipo(TipoUsuario.fromValor(usuarioDTO.getTipo()));
            usuario.get().setFkEmpresa(empresa.get());

            return Optional.of(usuarioRepository.save(usuario.get()));

        }else {
            return Optional.empty();
        }
    }

    public boolean deleteUsuario(Integer pkUsuario){
        Optional<Usuario> usuario = usuarioRepository.findById(pkUsuario);
        if (usuario.isPresent()){
            usuarioRepository.deleteById(pkUsuario);
            return true;
        }else {
            return false;
        }
    }
}
