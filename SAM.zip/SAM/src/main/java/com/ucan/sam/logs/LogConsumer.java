package com.ucan.sam.logs;

import com.ucan.sam.entities.DTO.LogDTO;
import com.ucan.sam.entities.Log;
import com.ucan.sam.mapper.LogMapper;
import com.ucan.sam.services.LogService;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class LogConsumer
{
    private final LogMapper logMapper;
    private final LogService logService;

    public LogConsumer(LogMapper logMapper, LogService logService)
    {
        this.logMapper = logMapper;
        this.logService = logService;
    }

    @KafkaListener(topics = "logs", groupId = "grupo-logs")
    private void LogTratamento(LogDTO logDTO){
        Log log = logMapper.toEntity(logDTO);
        System.out.println("Log recebido: " + log.getMensagem());
        logService.registrarLog(log);
    }
}
