package com.ucan.sam.entities;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "contacto")
public class Contacto implements Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pkContacto;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false, unique = true)
    private String telefone;

    public void setPkContacto(Integer pkContacto)
    {
        this.pkContacto = pkContacto;
    }

    public Integer getPkContacto()
    {
        return pkContacto;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getTelefone()
    {
        return telefone;
    }

    public void setTelefone(String telefone)
    {
        this.telefone = telefone;
    }
}
