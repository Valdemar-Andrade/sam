package com.ucan.sam.mensageria;

public class KafkaConsumerConfig
{
}
