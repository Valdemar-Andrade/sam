package com.ucan.sam.logs;

import com.ucan.sam.entities.DTO.LogDTO;
import com.ucan.sam.entities.Log;
import com.ucan.sam.mapper.LogMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class LogProducer
{
    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;
    @Autowired
    private LogMapper logMapper;

    public void enviarLog(Log log){
        LogDTO logDTO = logMapper.toDTO(log);
        kafkaTemplate.send("logs", logDTO);
    }
}
