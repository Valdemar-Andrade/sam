package com.ucan.sam.services;

import com.ucan.sam.entities.Contacto;
import com.ucan.sam.entities.DTO.EmpresaDTO;
import com.ucan.sam.entities.Empresa;
import com.ucan.sam.entities.Localidade;
import com.ucan.sam.repositories.ContactoRepository;
import com.ucan.sam.repositories.EmpresaRepository;
import com.ucan.sam.repositories.LocalidadeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class EmpresaService
{
    @Autowired
    private EmpresaRepository empresaRepository;
    @Autowired
    private LocalidadeRepository localidadeRepository;
    @Autowired
    private ContactoService contactoService;
    @Autowired
    private ContactoRepository contactoRepository;

    public Optional<Empresa> criarEmpresa(EmpresaDTO empresaDTO){

        Optional<Localidade> localidade = localidadeRepository.findById(empresaDTO.getFkLocalidade());

        if (localidade.isPresent()){
            Contacto contacto = new Contacto();
            contacto.setEmail(empresaDTO.getEmail());
            contacto.setTelefone(empresaDTO.getTelefone());

            Contacto contactoSalvo = contactoService.cadastrarContacto(contacto);

            Empresa empresa = new Empresa();
            empresa.setNome(empresaDTO.getNome());
            empresa.setFkContacto(contactoSalvo);
            empresa.setFkLocalidade(localidade.get());
            empresa.setDataCadastro(LocalDate.now());

            return Optional.of(empresaRepository.save(empresa));
        }else {
            return Optional.empty();
        }

    }

    public List<Empresa> findAll(){
        return empresaRepository.findAll();
    }

    public Optional<Empresa> findByPk(Integer pk){
        return empresaRepository.findById(pk);
    }

    public Optional<Empresa> updateEmpresa(EmpresaDTO empresaDTO)
    {
        Optional<Empresa> empresa = empresaRepository.findById(empresaDTO.getPkEmpresa());
        Optional<Localidade> localidade = localidadeRepository.findById(empresaDTO.getFkLocalidade());
        Optional<Contacto> contacto = contactoRepository.findContactoByTelefone(empresaDTO.getTelefone());

        if (empresa.isPresent() && localidade.isPresent() && contacto.isPresent()){

            contacto.get().setTelefone(empresaDTO.getTelefone());
            contacto.get().setEmail(empresaDTO.getEmail());
            Contacto contactoSalvo = contactoRepository.save(contacto.get());

            empresa.get().setNome(empresaDTO.getNome());
            empresa.get().setFkContacto(contactoSalvo);
            empresa.get().setFkLocalidade(localidade.get());

            return Optional.of(empresaRepository.save(empresa.get()));
        }else {
            return Optional.empty();
        }
    }

    public boolean delete(Integer pk){
        Optional<Empresa> empresa = empresaRepository.findById(pk);
        if (empresa.isPresent()){
            empresaRepository.deleteById(pk);
            return true;
        }else {
            return false;
        }
    }
}
