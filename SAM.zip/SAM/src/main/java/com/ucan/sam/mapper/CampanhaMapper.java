package com.ucan.sam.mapper;

import com.ucan.sam.entities.Campanha;
import com.ucan.sam.entities.DTO.CampanhaDTO;
import com.ucan.sam.entities.DTO.TopicoDTO;
import com.ucan.sam.entities.Empresa;
import com.ucan.sam.entities.Topico;
import com.ucan.sam.entities.Usuario;
import com.ucan.sam.enums.StatusCampanha;
import com.ucan.sam.repositories.EmpresaRepository;
import com.ucan.sam.repositories.TopicoRepository;
import com.ucan.sam.repositories.UsuarioRepository;
import com.ucan.sam.services.TopicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class CampanhaMapper
{
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private EmpresaRepository empresaRepository;
    @Autowired
    private TopicoService topicoService;

    public Campanha toEntity(CampanhaDTO campanhaDTO){
        Campanha campanha = new Campanha();
        Optional<Empresa> empresa = empresaRepository.findById(campanhaDTO.getFkEmpresa());
        Optional<Usuario> usuario = usuarioRepository.findById(campanhaDTO.getFkUsuario());

        if (empresa.isPresent() && usuario.isPresent()){
            campanha.setPkCampanha(campanhaDTO.getPkCampanha());
            campanha.setTitulo(campanhaDTO.getTitulo());
            campanha.setDescricao(campanhaDTO.getDescricao());
            campanha.setDataEnvio(campanhaDTO.getDataEnvio());
            campanha.setStatus(StatusCampanha.fromValor(campanhaDTO.getStatus()));
            campanha.setFkEmpresa(empresa.get());
            campanha.setFkUsuario(usuario.get());
            campanha.setTopicosRelacionados(topicoService.getEntityByPkList(campanhaDTO.getTopicosRelacionados()));
        }
        return campanha;
    }

    public CampanhaDTO toDTO(Campanha campanha){
        CampanhaDTO campanhaDTO = new CampanhaDTO();
        Optional<Empresa> empresa = empresaRepository.findById(campanha.getFkEmpresa().getPkEmpresa());

        if (empresa.isPresent()){
            campanhaDTO.setPkCampanha(campanha.getPkCampanha());
            campanhaDTO.setTitulo(campanha.getTitulo());
            campanhaDTO.setDescricao(campanha.getDescricao());
            campanhaDTO.setStatus(campanha.getStatus().getValor());
            campanhaDTO.setFkEmpresa(empresa.get().getPkEmpresa());
            campanhaDTO.setTopicosRelacionados(topicoService.getPkByEntityList(campanha.getTopicosRelacionados()));
            campanhaDTO.setDataEnvio(campanha.getDataEnvio());
            campanhaDTO.setFkUsuario(campanha.getFkUsuario().getPkUsuario());

            return campanhaDTO;
        }else {
            return campanhaDTO;
        }
    }

    public List<CampanhaDTO> toDTO(List<Campanha> campanhas){
        List<CampanhaDTO> campanhasDTO = new ArrayList<>();

        for (Campanha c : campanhas){
            campanhasDTO.add(this.toDTO(c));
        }
        return campanhasDTO;
    }
}
