package com.ucan.sam.services;

import com.ucan.sam.entities.Campanha;
import com.ucan.sam.entities.DTO.CampanhaDTO;
import com.ucan.sam.entities.Mensagem;
import com.ucan.sam.enums.StatusMensagem;
import com.ucan.sam.mapper.CampanhaMapper;
import com.ucan.sam.repositories.CampanhaRepository;
import com.ucan.sam.repositories.MensagemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class MensagemService
{
    @Autowired
    private MensagemRepository mensagemRepository;

    @Autowired
    private EmailService emailService;

    @Autowired
    private SmsService smsService;
    @Autowired
    private CampanhaRepository campanhaRepository;

    public void processarMensagensPorCampanha(Campanha campanha) {
        // buscar todas as mensagens associadas a campanha
        List<Mensagem> mensagens = mensagemRepository.findByFkCampanha_PkCampanha(campanha.getPkCampanha());

        for (Mensagem mensagem : mensagens) {
            boolean sucesso;

            try {
                if (mensagem.getFkLead().getFkPessoa().getFkContacto().getEmail() != null) {
                    sucesso = emailService.enviarEmail(
                            mensagem.getFkLead().getFkPessoa().getFkContacto().getEmail(),
                            "Campanha: " + campanha.getTitulo(),
                            "Conteúdo da campanha: " + campanha.getDescricao()
                    );
                } else if (mensagem.getFkLead().getFkPessoa().getFkContacto().getTelefone() != null) {
                    sucesso = smsService.enviarSms(
                            mensagem.getFkLead().getFkPessoa().getFkContacto().getTelefone(),
                            "Campanha: " + campanha.getTitulo()
                    );
                } else {
                    sucesso = false;
                }

                mensagem.setStatus(sucesso ? StatusMensagem.ENTREGUE : StatusMensagem.FALHOU);
            } catch (Exception e) {
                mensagem.setStatus(StatusMensagem.FALHOU);
                System.err.println("Erro ao enviar mensagem para o lead: " + mensagem.getFkLead().getFkPessoa().getNome());
            }

            mensagem.setDataEnvio(LocalDateTime.now());
            mensagemRepository.save(mensagem);

            System.out.println("Mensagem para " + mensagem.getFkLead().getFkPessoa().getNome() + " - Status: " + mensagem.getStatus());
        }
    }

    public Optional<Campanha> getCampanhaEntityByDTO(CampanhaDTO campanhaDTO)
    {
        return campanhaRepository.findById(campanhaDTO.getPkCampanha());
    }
}
