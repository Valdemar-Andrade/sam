package com.ucan.sam.services;

import org.springframework.stereotype.Service;

@Service
public class EmailService
{
    public boolean enviarEmail(String para, String assunto, String conteudo) {
        // Simulação de envio
        System.out.println("Enviando email para: " + para);
        return true; // Sucesso
    }
}
