package com.ucan.sam.services;

import org.springframework.stereotype.Service;

@Service
public class SmsService
{
    public boolean enviarSms(String para, String mensagem) {
        // Simulação de envio
        System.out.println("Enviando SMS para: " + para);
        return true; // Sucesso
    }
}
