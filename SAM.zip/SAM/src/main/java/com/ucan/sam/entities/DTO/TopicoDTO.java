package com.ucan.sam.entities.DTO;

import com.ucan.sam.entities.Topico;
import org.springframework.beans.BeanUtils;

public class TopicoDTO
{
    private Integer pkTopico;
    private String nome;
    private String descricao;

    public TopicoDTO(Topico topico)
    {
        BeanUtils.copyProperties(topico, this);
    }

    public TopicoDTO()
    {
    }

    public Integer getPkTopico()
    {
        return pkTopico;
    }

    public void setPkTopico(Integer pkTopico)
    {
        this.pkTopico = pkTopico;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public String getDescricao()
    {
        return descricao;
    }

    public void setDescricao(String descricao)
    {
        this.descricao = descricao;
    }
}
