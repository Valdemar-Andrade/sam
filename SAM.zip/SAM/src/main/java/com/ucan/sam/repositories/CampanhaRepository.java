package com.ucan.sam.repositories;

import com.ucan.sam.entities.Campanha;
import com.ucan.sam.enums.StatusCampanha;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface CampanhaRepository extends JpaRepository<Campanha, Integer>
{
    @EntityGraph(attributePaths = {"topicosRelacionados"})
    List<Campanha> findByDataEnvioBeforeAndStatus(LocalDateTime dataEnvio, StatusCampanha status);

    @EntityGraph(attributePaths = {"topicosRelacionados"})
    Optional<Campanha> findById(Integer pkCampanha);
}
