package com.ucan.sam.repositories;

import com.ucan.sam.entities.Campanha;
import com.ucan.sam.enums.StatusCampanha;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface CampanhaRepository extends JpaRepository<Campanha, Integer>
{
    List<Campanha> findByDataEnvioBeforeAndStatus(LocalDateTime dataEnvio, StatusCampanha status);
}
