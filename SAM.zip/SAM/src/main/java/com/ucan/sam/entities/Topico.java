package com.ucan.sam.entities;

import com.ucan.sam.entities.DTO.TopicoDTO;
import jakarta.persistence.*;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "topico")
public class Topico implements Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pkTopico;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false)
    private String descricao;

    @ManyToMany
    private List<Campanha> campanhas;

    @ManyToMany
    private List<Lead> leads;

    public Topico(TopicoDTO topicoDTO)
    {
        BeanUtils.copyProperties(topicoDTO, this);
    }

    public Topico(){
    }

    public Integer getPkTopico()
    {
        return pkTopico;
    }

    public void setPkTopico(Integer pkTopico)
    {
        this.pkTopico = pkTopico;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public String getDescricao()
    {
        return descricao;
    }

    public void setDescricao(String descricao)
    {
        this.descricao = descricao;
    }

    public List<Campanha> getCampanhas()
    {
        return campanhas;
    }

    public void setCampanhas(List<Campanha> campanhas)
    {
        this.campanhas = campanhas;
    }

    public List<Lead> getLeads()
    {
        return leads;
    }

    public void setLeads(List<Lead> leads)
    {
        this.leads = leads;
    }
}
