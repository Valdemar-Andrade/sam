package com.ucan.sam.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ucan.sam.entities.DTO.EmpresaDTO;
import jakarta.persistence.*;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "empresa")
public class Empresa implements Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pkEmpresa;

    @Column(nullable = false)
    private String nome;

    @OneToOne
    private Localidade fkLocalidade;

    private LocalDate dataCadastro;

    @OneToOne
    private Contacto fkContacto;

    @OneToMany(cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Usuario> usuarios;

    @OneToMany(cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Campanha> campanhas;

    @OneToMany(cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Lead> leads;

    public Empresa(EmpresaDTO empresaDTO){
        BeanUtils.copyProperties(empresaDTO, this);
    }

    public Empresa(){

    }

    public Integer getPkEmpresa()
    {
        return pkEmpresa;
    }

    public void setPkEmpresa(Integer pkEmpresa)
    {
        this.pkEmpresa = pkEmpresa;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public Contacto getFkContacto()
    {
        return fkContacto;
    }

    public void setFkContacto(Contacto fkContacto)
    {
        this.fkContacto = fkContacto;
    }

    public Localidade getFkLocalidade()
    {
        return fkLocalidade;
    }

    public void setFkLocalidade(Localidade fkLocalidade)
    {
        this.fkLocalidade = fkLocalidade;
    }

    public LocalDate getDataCadastro()
    {
        return dataCadastro;
    }

    public void setDataCadastro(LocalDate dataCadastro)
    {
        this.dataCadastro = dataCadastro;
    }

    public List<Usuario> getUsuarios()
    {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios)
    {
        this.usuarios = usuarios;
    }

    public List<Campanha> getCampanhas()
    {
        return campanhas;
    }

    public void setCampanhas(List<Campanha> campanhas)
    {
        this.campanhas = campanhas;
    }

    public List<Lead> getLeads()
    {
        return leads;
    }

    public void setLeads(List<Lead> leads)
    {
        this.leads = leads;
    }
}
