package com.ucan.sam.entities;

import com.ucan.sam.enums.Sexo;
import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "pessoa")
public class Pessoa implements Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pkPessoa;

    private String nome;

    @Enumerated(EnumType.ORDINAL)
    private Sexo sexo;

    @OneToOne
    private Contacto fkContacto;

    @OneToOne
    private Localidade fkLocalidade;

    public Integer getPkPessoa()
    {
        return pkPessoa;
    }

    public void setPkPessoa(Integer pkPessoa)
    {
        this.pkPessoa = pkPessoa;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public Sexo getSexo()
    {
        return sexo;
    }

    public void setSexo(Sexo sexo)
    {
        this.sexo = sexo;
    }

    public Contacto getFkContacto()
    {
        return fkContacto;
    }

    public void setFkContacto(Contacto fkContacto)
    {
        this.fkContacto = fkContacto;
    }

    public Localidade getFkLocalidade()
    {
        return fkLocalidade;
    }

    public void setFkLocalidade(Localidade fkLocalidade)
    {
        this.fkLocalidade = fkLocalidade;
    }
}
