package com.ucan.sam.services;

import com.ucan.sam.entities.DTO.TopicoDTO;
import com.ucan.sam.entities.Topico;
import com.ucan.sam.mapper.TopicoMapper;
import com.ucan.sam.repositories.TopicoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TopicoService
{
    @Autowired
    private TopicoRepository topicoRepository;
    @Autowired
    private TopicoMapper topicoMapper;

    public Optional<Topico> criarTopico(TopicoDTO topicoDTO){
        Topico topico = topicoMapper.toEntity(topicoDTO);
        return Optional.of(topicoRepository.save(topico));
    }

    public List<Topico> findAll(){
        return topicoRepository.findAll();
    }

    public Optional<Topico> findByPk(Integer pk){
        return topicoRepository.findById(pk);
    }

    // converter lista de chaves de Topicos para entidades respectivas
    public List<Topico> getEntityByPkList(List<Integer> topicos){
        List<Topico> topicosEntidade = new ArrayList<>();
        for (Integer topicoPk : topicos){
            Optional<Topico> topico = topicoRepository.findById(topicoPk);
            if (topico.isPresent()){
                topicosEntidade.add(topico.get());
            }
        }
        return topicosEntidade;
    }

    public List<Integer> getPkByEntityList(List<Topico> topicosInteresse){
        List<Integer> topicos = new ArrayList<>();
        for (Topico topicoPk : topicosInteresse){
            Optional<Topico> topico = topicoRepository.findById(topicoPk.getPkTopico());
            if (topico.isPresent()){
                topicos.add(topico.get().getPkTopico());
            }
        }
        return topicos;
    }

    public Optional<Topico> updateTopico(TopicoDTO topicoDTO)
    {
        Optional<Topico> topico = topicoRepository.findById(topicoDTO.getPkTopico());
        if (topico.isPresent()){
            topico.get().setNome(topicoDTO.getNome());
            topico.get().setDescricao(topicoDTO.getDescricao());

            return Optional.of(topicoRepository.save(topico.get()));
        }else {
            return Optional.empty();
        }
    }

    public boolean deleteTopico(Integer pk)
    {
        Optional<Topico> topico = topicoRepository.findById(pk);
        if (topico.isPresent()){
            topicoRepository.deleteById(pk);
            return true;
        }else {
            return false;
        }
    }
}
