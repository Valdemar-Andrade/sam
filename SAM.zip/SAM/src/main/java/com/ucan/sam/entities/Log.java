package com.ucan.sam.entities;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "log")
public class Log implements Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pkLog;

    private String mensagem;
    private LocalDateTime data;

    public void setPkLog(Integer pkLog)
    {
        this.pkLog = pkLog;
    }

    public Integer getPkLog()
    {
        return pkLog;
    }

    public String getMensagem()
    {
        return mensagem;
    }

    public void setMensagem(String mensagem)
    {
        this.mensagem = mensagem;
    }

    public LocalDateTime getData()
    {
        return data;
    }

    public void setData(LocalDateTime data)
    {
        this.data = data;
    }
}
