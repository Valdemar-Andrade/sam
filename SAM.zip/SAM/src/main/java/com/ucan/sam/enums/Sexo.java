package com.ucan.sam.enums;

public enum Sexo
{
    MASCULINO(0),
    FEMININO(1);

    private final int valor;

    Sexo(int valor){
        this.valor = valor;
    }

    public int getValor() {
        return valor;
    }

    public static Sexo fromValor(int valor){
        for (Sexo sexo : Sexo.values()){
            if (sexo.getValor() == valor){
                return sexo;
            }
        }
        throw new IllegalArgumentException("Valor inválido para TipoUsuario: " + valor);
    }
}
