package com.ucan.sam.security;

import com.ucan.sam.enums.TipoUsuario;

public class LoginResponse
{
    private String token;
    private TipoUsuario role;

    public LoginResponse(String token, TipoUsuario role) {
        this.token = token;
        this.role = role;
    }

    public String getToken()
    {
        return token;
    }

    public void setToken(String token)
    {
        this.token = token;
    }

    public TipoUsuario getRole()
    {
        return role;
    }

    public void setRole(TipoUsuario role)
    {
        this.role = role;
    }
}
