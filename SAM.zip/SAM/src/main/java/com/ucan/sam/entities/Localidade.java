package com.ucan.sam.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

import java.io.Serializable;
import java.util.List;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler", "localidadeList"})
@Entity
@Table(name = "localidade")
public class Localidade implements Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "pk_localidade")
    private Integer pkLocalidade;

    @Basic(optional = false)
    @Column(name = "nome")
    private String nome;

    @OneToMany(mappedBy = "fkLocalidadePai")
    private List<Localidade> localidadeList;

    @JoinColumn(name = "fk_localidade_pai", referencedColumnName = "pk_localidade")
    @ManyToOne
    private Localidade fkLocalidadePai;

    public Localidade()
    {
    }

    public Localidade(Integer pkLocalidade)
    {
        this.pkLocalidade = pkLocalidade;
    }

    public Localidade(Integer pkLocalidade, String nome)
    {
        this.pkLocalidade = pkLocalidade;
        this.nome = nome;
    }

    public Localidade(String nome)
    {
        this.nome = nome;
    }

    @Override
    public String toString()
    {
        return "[pkLocalidade: " + pkLocalidade +
                ", nome: " + nome + "]";
    }

    public Integer getPkLocalidade()
    {
        return pkLocalidade;
    }

    public void setPkLocalidade(Integer pkLocalidade)
    {
        this.pkLocalidade = pkLocalidade;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public List<Localidade> getLocalidadeList()
    {
        return localidadeList;
    }

    public void setLocalidadeList(List<Localidade> localidadeList)
    {
        this.localidadeList = localidadeList;
    }

    public Localidade getFkLocalidadePai()
    {
        return fkLocalidadePai;
    }

    public void setFkLocalidadePai(Localidade fkLocalidadePai)
    {
        this.fkLocalidadePai = fkLocalidadePai;
    }
}
