package com.ucan.sam.controllers;

import com.ucan.sam.entities.DTO.UsuarioDTO;
import com.ucan.sam.entities.Log;
import com.ucan.sam.entities.Pessoa;
import com.ucan.sam.entities.Usuario;
import com.ucan.sam.enums.Sexo;
import com.ucan.sam.logs.LogProducer;
import com.ucan.sam.mapper.UsuarioMapper;
import com.ucan.sam.security.AuthUtil;
import com.ucan.sam.services.UsuarioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/usuario")
public class UsuarioController
{
    @Autowired
    UsuarioService usuarioService;
    @Autowired
    UsuarioMapper usuarioMapper;
    @Autowired
    private LogProducer logProducer;

    @PostMapping
    public ResponseEntity<?> criarUsuario(@RequestBody UsuarioDTO usuarioDTO, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForAdmin(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Usuario> usuarioSalvo = usuarioService.criarUsuario(usuarioDTO);

            Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
            if (usuarioSalvo.isPresent()){
                logProducer.enviarLog("Usuario criado pelo admin: " + usuario.getFkPessoa().getNome());
                return ResponseEntity.ok(usuarioMapper.toDTO(usuarioSalvo.get()));
            }else {
                logProducer.enviarLog("Erro ao criar Usuario pelo admin: " + usuario.getFkPessoa().getNome());
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erro ao criar o Usuario!");
            }
        }else {
            return auth;
        }
    }

    @GetMapping
    public ResponseEntity<?> findAll(HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForAdmin(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            List<Usuario> usuarios = usuarioService.findAll();
            List<UsuarioDTO> usuariosDTO = new ArrayList<>();

            if (usuarios.isEmpty()){
                return ResponseEntity.noContent().build();
            }else {
                for (Usuario usuario : usuarios){
                    usuariosDTO.add(usuarioMapper.toDTO(usuario));
                }
                return ResponseEntity.ok(usuariosDTO);
            }
        }else {
            return auth;
        }
    }

    @GetMapping("/{pk}")
    public ResponseEntity<?> findByPk(@PathVariable Integer pk, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForAdmin(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Usuario> usuario = usuarioService.findByPk(pk);

            if (usuario.isPresent()){
                return ResponseEntity.ok(usuarioMapper.toDTO(usuario.get()));
            }else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuário não encontrado!");
            }
        }else {
            return auth;
        }
    }

    @PutMapping
    public ResponseEntity<?> updateUsuario(@RequestBody UsuarioDTO usuarioDTO, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForAdmin(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Usuario> usuarioAtualizado = usuarioService.updateUsuario(usuarioDTO);
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            if (usuarioAtualizado.isPresent()){
                logProducer.enviarLog("Usuario atualizado pelo admin: " + usuarioLogado.getFkPessoa().getNome());
                return ResponseEntity.ok(usuarioMapper.toDTO(usuarioAtualizado.get()));
            }else {
                logProducer.enviarLog("Erro ao atualizar Usuario pelo admin: " + usuarioLogado.getFkPessoa().getNome());
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(usuarioDTO);
            }
        }else {
            return auth;
        }
    }

    @DeleteMapping("/{pk}")
    public ResponseEntity<?> deleteUsuario(@PathVariable Integer pk, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForAdmin(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            if (usuarioService.deleteUsuario(pk)){
                logProducer.enviarLog("Usuario deletado pelo admin: " + usuarioLogado.getFkPessoa().getNome());
                return ResponseEntity.status(HttpStatus.OK).body("Usuário Deletado com sucesso!");
            }else {
                logProducer.enviarLog("Erro ao deletar Usuario pelo admin: " + usuarioLogado.getFkPessoa().getNome());
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuário não encontrado!");
            }
        }else {
            return auth;
        }
    }
}
