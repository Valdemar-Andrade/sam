package com.ucan.sam.services;

import com.ucan.sam.entities.Log;
import com.ucan.sam.repositories.LogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LogService
{
    @Autowired
    private LogRepository logRepository;

    public void registrarLog(Log log){
        logRepository.save(log);
    }

    public List<Log> findAll()
    {
        return logRepository.findAll();
    }
}
