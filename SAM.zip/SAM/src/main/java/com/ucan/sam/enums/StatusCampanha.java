package com.ucan.sam.enums;

public enum StatusCampanha
{
    AGENDADA(1), // Campanha aguardando envio
    ENVIADA(2),  // Campanha já enviada
    CANCELADA(3); // Campanha cancelada antes do envio

    private final int valor;


    StatusCampanha(int valor)
    {
        this.valor = valor;
    }

    public int getValor() {
        return valor;
    }

    public static StatusCampanha fromValor(int valor){
        for (StatusCampanha statusCampanha : StatusCampanha.values()){
            if (statusCampanha.getValor() == valor){
                return statusCampanha;
            }
        }
        throw new IllegalArgumentException("Valor inválido para StatusCampanha: " + valor);
    }
}
