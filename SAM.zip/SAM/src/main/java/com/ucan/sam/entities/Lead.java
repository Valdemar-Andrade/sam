package com.ucan.sam.entities;

import com.ucan.sam.entities.DTO.LeadDTO;
import jakarta.persistence.*;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "lead")
public class Lead implements Serializable
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pkLead;

    @OneToOne
    private Pessoa fkPessoa;

    @ManyToMany
    private List<Topico> topicosInteresse;

    @ManyToMany
    private List<Empresa> fkEmpresa;

    public Lead(LeadDTO leadDTO){
        BeanUtils.copyProperties(leadDTO, this);
    }

    public Lead()
    {
    }

    public Integer getPkLead()
    {
        return pkLead;
    }

    public void setPkLead(Integer pkLead)
    {
        this.pkLead = pkLead;
    }

    public Pessoa getFkPessoa()
    {
        return fkPessoa;
    }

    public void setFkPessoa(Pessoa fkPessoa)
    {
        this.fkPessoa = fkPessoa;
    }

    public List<Topico> getTopicosInteresse()
    {
        return topicosInteresse;
    }

    public void setTopicosInteresse(List<Topico> topicosInteresse)
    {
        this.topicosInteresse = topicosInteresse;
    }

    public List<Empresa> getFkEmpresa()
    {
        return fkEmpresa;
    }

    public void setFkEmpresa(List<Empresa> fkEmpresa)
    {
        this.fkEmpresa = fkEmpresa;
    }
}
