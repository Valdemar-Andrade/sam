package com.ucan.sam.services;

import com.ucan.sam.entities.*;
import com.ucan.sam.entities.DTO.CampanhaDTO;
import com.ucan.sam.enums.StatusCampanha;
import com.ucan.sam.enums.StatusMensagem;
import com.ucan.sam.mapper.CampanhaMapper;
import com.ucan.sam.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CampanhaService
{
    @Autowired
    private CampanhaRepository campanhaRepository;

    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

    @Autowired
    private LeadRepository leadRepository;

    @Autowired
    private MensagemRepository mensagemRepository;

    @Autowired
    private MensagemService mensagemService;

    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private CampanhaMapper campanhaMapper;
    @Autowired
    private TopicoRepository topicoRepository;

    public Optional<Campanha> criarCampanha(CampanhaDTO campanhaDTO) {

        campanhaDTO.setStatus(StatusCampanha.ENVIADA.getValor());
        campanhaDTO.setDataEnvio(LocalDateTime.now());
        Campanha campanha = campanhaMapper.toEntity(campanhaDTO);

        List<Topico> topicos = new ArrayList<>();
        // validar se cada topico recebido existe
        for (Topico t : campanha.getTopicosRelacionados()){
            Optional<Topico> topico = topicoRepository.findById(t.getPkTopico());

            if (topico.isPresent()){
                topicos.add(topico.get());
            }else {
                return Optional.empty();
            }
        }
        // setar os topicos da campanha com suas informacoes completas
        campanha.setTopicosRelacionados(topicos);
        Optional<Campanha> campanhaSalva = Optional.of(campanhaRepository.save(campanha));

        // buscar leads associados aos topicos da campanha
        List<Lead> leads = leadRepository.findLeadByTopicosInteresseIn(campanha.getTopicosRelacionados());

        for (Lead lead : leads) {
            Mensagem mensagem = new Mensagem();
            mensagem.setFkCampanha(campanhaSalva.get());
            mensagem.setFkLead(lead);
            mensagem.setDataEnvio(LocalDateTime.now());
            mensagem.setStatus(StatusMensagem.ENVIADO);

            mensagemRepository.save(mensagem);
        }

        mensagemService.processarMensagensPorCampanha(campanha);

        CampanhaDTO campDTO;
        campDTO = campanhaMapper.toDTO(campanhaSalva.get());

        // publicar evento no Kafka
        kafkaTemplate.send("campanhas", campDTO);
        return campanhaSalva;
    }

    public Optional<Campanha> criarCampanhaAgendada(Campanha campanha, Usuario usuario) {

        if (campanha.getDataEnvio().isBefore(LocalDateTime.now())){
            return Optional.empty();
        }

        campanha.setStatus(StatusCampanha.AGENDADA);
        campanha.setFkUsuario(usuario);
        Optional<Campanha> salva = Optional.of(campanhaRepository.save(campanha));

        // buscar leads associados aos topicos da campanha
        List<Lead> leads = leadRepository.findLeadByTopicosInteresseIn(campanha.getTopicosRelacionados());

        for (Lead lead : leads) {
            Mensagem mensagem = new Mensagem();
            mensagem.setFkCampanha(salva.get());
            mensagem.setFkLead(lead);
            mensagem.setDataEnvio(LocalDateTime.now());
            mensagem.setStatus(StatusMensagem.ENVIADO);

            mensagemRepository.save(mensagem);
        }

        // publicar evento no Kafka
        kafkaTemplate.send("campanhas", salva.get());
        return salva;
    }

    @Scheduled(fixedRate = 60000) // Executa a cada 60 segundos
    public void processarCampanhasAgendadas() {
        LocalDateTime agora = LocalDateTime.now();
        //System.out.println("Scheduler rodando em: " + LocalDateTime.now());

        // buscar campanhas agendadas para envio que ainda nao foram processadas
        List<Campanha> campanhas = campanhaRepository.findByDataEnvioBeforeAndStatus(agora, StatusCampanha.AGENDADA);

        for (Campanha campanha : campanhas) {
            try {
                System.out.println("Processando campanha: " + campanha.getTitulo());

                // disparar envio de mensagens
                mensagemService.processarMensagensPorCampanha(campanha);
                campanha.setStatus(StatusCampanha.ENVIADA);
                campanhaRepository.save(campanha);

            } catch (Exception e) {
                System.err.println("Erro ao processar campanha " + campanha.getPkCampanha() + ": " + e.getMessage());
            }
        }
    }

    public Optional<Campanha> findCampanhaByPk(Integer pk){
        return campanhaRepository.findById(pk);
    }

    public List<Campanha> findAll(){
        return campanhaRepository.findAll();
    }

    public Optional<Campanha> updateCampanha(Campanha campanhaAtualizada)
    {
        Optional<Campanha> campanha = campanhaRepository.findById(campanhaAtualizada.getPkCampanha());
        if (campanha.isPresent()){
            campanha.get().setDataEnvio(campanhaAtualizada.getDataEnvio());
            campanha.get().setStatus(campanhaAtualizada.getStatus());
            campanha.get().setDescricao(campanhaAtualizada.getDescricao());
            campanha.get().setTitulo(campanhaAtualizada.getTitulo());
            campanha.get().setTopicosRelacionados(campanhaAtualizada.getTopicosRelacionados());
            campanha.get().setMensagens(campanhaAtualizada.getMensagens());
            campanha.get().setFkUsuario(campanhaAtualizada.getFkUsuario());
            campanha.get().setFkEmpresa(campanhaAtualizada.getFkEmpresa());

            return Optional.of(campanhaRepository.save(campanha.get()));
        }else {
            return Optional.empty();
        }
    }

    public boolean delete(Integer pkCampanha){
        Optional<Campanha> campanha = campanhaRepository.findById(pkCampanha);
        if (campanha.isPresent()){
            campanhaRepository.deleteById(pkCampanha);
            return true;
        }else {
            return false;
        }
    }
}
