package com.ucan.sam.converter;

import com.ucan.sam.enums.TipoUsuario;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = true)
public class TipoUsuarioConverter implements AttributeConverter<TipoUsuario, Integer>
{
    @Override
    public Integer convertToDatabaseColumn(TipoUsuario tipoUsuario) {
        return tipoUsuario != null ? tipoUsuario.getValor() : null;
    }

    @Override
    public TipoUsuario convertToEntityAttribute(Integer valor) {
        return valor != null ? TipoUsuario.fromValor(valor) : null;
    }
}
