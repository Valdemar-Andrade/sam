package com.ucan.sam.converter;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.ucan.sam.enums.TipoUsuario;

import java.io.IOException;

public class TipoUsuarioDeserializer extends JsonDeserializer<TipoUsuario>
{
    @Override
    public TipoUsuario deserialize(JsonParser parser, DeserializationContext context) throws IOException
    {
        int valor = parser.getIntValue(); // Captura o número enviado no JSON
        return TipoUsuario.fromValor(valor); // Converte para o enum usando o metodo fromValor
    }
}
