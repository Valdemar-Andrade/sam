package com.ucan.sam.repositories;

import com.ucan.sam.entities.Lead;
import com.ucan.sam.entities.Topico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LeadRepository extends JpaRepository<Lead, Integer>
{
    List<Lead> findLeadByTopicosInteresseIn(List<Topico> topicos);
}
