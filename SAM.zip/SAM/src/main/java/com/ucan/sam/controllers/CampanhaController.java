package com.ucan.sam.controllers;

import com.ucan.sam.entities.Campanha;
import com.ucan.sam.entities.DTO.CampanhaDTO;
import com.ucan.sam.entities.Usuario;
import com.ucan.sam.logs.LogProducer;
import com.ucan.sam.mapper.CampanhaMapper;
import com.ucan.sam.security.AuthUtil;
import com.ucan.sam.services.CampanhaService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/campanha")
public class CampanhaController
{
    @Autowired
    private CampanhaService campanhaService;
    @Autowired
    private CampanhaMapper campanhaMapper;
    @Autowired
    private LogProducer logProducer;

    @PostMapping
    public ResponseEntity<?> criarCampanha(@RequestBody CampanhaDTO campanhaDTO, HttpSession session){

        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK))
        {
            Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
            campanhaDTO.setFkUsuario(usuario.getPkUsuario());
            Optional<Campanha> novaCampanha = campanhaService.criarCampanha(campanhaDTO);

            if (novaCampanha.isPresent()){
                logProducer.enviarLog("Campanha criada pelo Usuario: " + usuario.getFkPessoa().getNome());
                return ResponseEntity.ok(campanhaMapper.toDTO(novaCampanha.get()));
            }else {
                logProducer.enviarLog("Falha ao criar Campanha pelo Usuario: " + usuario.getFkPessoa().getNome());
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erro ao criar a Campanha!");
            }
        }else {
            return auth;
        }
    }

    @PostMapping("/agendar")
    public ResponseEntity<?> criarCampanhaAgendada(@RequestBody CampanhaDTO campanhaDTO, HttpSession session) {

        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK))
        {
            Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
            campanhaDTO.setFkUsuario(usuario.getPkUsuario());
            Optional<Campanha> novaCampanha = campanhaService.criarCampanhaAgendada(campanhaDTO);

            if (novaCampanha.isPresent()){
                campanhaService.processarCampanhasAgendadas();
                logProducer.enviarLog("Campanha agendada: " + novaCampanha.get().getTitulo() + " pelo Usuario: " + usuario.getFkPessoa().getNome());
                return ResponseEntity.ok(campanhaMapper.toDTO(novaCampanha.get()));
            }else {
                logProducer.enviarLog("Erro ao agendar Campanha pelo Usuario: " + usuario.getFkPessoa().getNome());
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erro ao criar a Campanha!");
            }
        }else {
            return auth;
        }
    }

    @GetMapping("/{pk}")
    public ResponseEntity<Object> findCampanhaByPk(@PathVariable Integer pk, HttpSession session){

        if (AuthUtil.isUserAuthenticated(session)){
            Optional<Campanha> campanha = campanhaService.findCampanhaByPk(pk);

            if (campanha.isPresent()){
                return ResponseEntity.ok(campanhaMapper.toDTO(campanha.get()));
            }else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Campanha não encontrada!");
            }
        }else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Usuário não autenticado");
        }
    }

    @GetMapping
    public ResponseEntity<?> findAll(HttpSession session){

        if (AuthUtil.isUserAuthenticated(session)){
            List<Campanha> campanhas = campanhaService.findAll();

            if (campanhas.isEmpty()){
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Não existem Campanhas");
            }
            return ResponseEntity.ok(campanhaMapper.toDTO(campanhas));
        }else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Usuário não autenticado");
        }
    }

    @PutMapping
    public ResponseEntity<?> updateCampanha(@RequestBody CampanhaDTO campanhaDTO, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Campanha> campanhaAtualizada = campanhaService.updateCampanha(campanhaMapper.toEntity(campanhaDTO));
            if (campanhaAtualizada.isPresent()){
                Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
                logProducer.enviarLog("Campanha atualizada: " + campanhaAtualizada.get().getTitulo() + " pelo Usuario: " + usuario.getFkPessoa().getNome());
                return ResponseEntity.ok(campanhaMapper.toDTO(campanhaAtualizada.get()));
            }else {
                Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
                logProducer.enviarLog("Falha ao atualizar Campanha pelo Usuario: " + usuario.getFkPessoa().getNome());
                return ResponseEntity.badRequest().body("Erro ao atualizar campanha!");
            }
        }else {
            return auth;
        }
    }

    @DeleteMapping("/{pk}")
    public ResponseEntity<?> delete(@PathVariable Integer pk, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForUser(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){

            if (campanhaService.delete(pk)){
                Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
                logProducer.enviarLog("Campanha deletada pelo Usuario: " + usuario.getFkPessoa().getNome());
                return ResponseEntity.ok("Campanha Deletada com sucesso!");
            }else {
                Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
                logProducer.enviarLog("Erro ao deletar Campanha pelo Usuario: " + usuario.getFkPessoa().getNome());
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Campanha não encontrada.");
            }
        }else {
            return auth;
        }
    }

}
