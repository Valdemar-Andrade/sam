package com.ucan.sam.mapper;

import com.ucan.sam.entities.Contacto;
import com.ucan.sam.entities.DTO.EmpresaDTO;
import com.ucan.sam.entities.Empresa;
import com.ucan.sam.entities.Localidade;
import com.ucan.sam.repositories.LocalidadeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Optional;

@Component
public class EmpresaMapper
{
    @Autowired
    private LocalidadeRepository localidadeRepository;

    public Optional<Empresa> toEntity(EmpresaDTO empresaDTO){
        Empresa empresa = new Empresa();
        Optional<Localidade> localidade = localidadeRepository.findById(empresaDTO.getFkLocalidade());

        if (localidade.isPresent()){
            Contacto contacto = new Contacto();
            contacto.setTelefone(empresaDTO.getTelefone());
            contacto.setEmail(empresaDTO.getEmail());

            empresa.setPkEmpresa(empresaDTO.getPkEmpresa());
            empresa.setNome(empresaDTO.getNome());
            empresa.setFkContacto(contacto);
            empresa.setFkLocalidade(localidade.get());
            empresa.setDataCadastro(LocalDate.now());

            return Optional.of(empresa);
        }else {
            return Optional.empty();
        }
    }

    public EmpresaDTO toDTO(Empresa empresa){
        EmpresaDTO empresaDTO = new EmpresaDTO();

        empresaDTO.setPkEmpresa(empresa.getPkEmpresa());
        empresaDTO.setNome(empresa.getNome());
        empresaDTO.setEmail(empresa.getFkContacto().getEmail());
        empresaDTO.setTelefone(empresa.getFkContacto().getTelefone());
        empresaDTO.setDataCadastro(empresa.getDataCadastro());
        empresaDTO.setFkLocalidade(empresa.getFkLocalidade().getPkLocalidade());

        return empresaDTO;
    }
}
