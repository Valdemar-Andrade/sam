package com.ucan.sam.mensageria;

public class KafkaTopics
{
}
