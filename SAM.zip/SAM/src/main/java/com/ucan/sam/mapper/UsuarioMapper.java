package com.ucan.sam.mapper;

import com.ucan.sam.entities.*;
import com.ucan.sam.entities.DTO.EmpresaDTO;
import com.ucan.sam.entities.DTO.UsuarioDTO;
import com.ucan.sam.enums.Sexo;
import com.ucan.sam.enums.TipoUsuario;
import com.ucan.sam.repositories.EmpresaRepository;
import com.ucan.sam.repositories.LocalidadeRepository;
import com.ucan.sam.repositories.PessoaRepository;
import com.ucan.sam.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class UsuarioMapper
{
    @Autowired
    private LocalidadeRepository localidadeRepository;
    @Autowired
    private EmpresaMapper empresaMapper;
    @Autowired
    private EmpresaRepository empresaRepository;
    @Autowired
    private PessoaRepository pessoaRepository;

    public Optional<Usuario> toEntity(UsuarioDTO usuarioDTO){

        Optional<Localidade> localidade = localidadeRepository.findById(usuarioDTO.getFkLocalidade());
        Optional<Empresa> empresa = empresaRepository.findById(usuarioDTO.getFkEmpresa());
        Usuario usuario = new Usuario();

        if (localidade.isPresent() && empresa.isPresent()){
            Contacto contacto = new Contacto();
            contacto.setTelefone(usuarioDTO.getTelefone());
            contacto.setEmail(usuarioDTO.getEmail());

            Pessoa pessoa = new Pessoa();
            pessoa.setSexo(Sexo.fromValor(usuarioDTO.getSexo()));
            pessoa.setNome(usuarioDTO.getNome());
            pessoa.setFkLocalidade(localidade.get());
            pessoa.setFkContacto(contacto);

            usuario.setPkUsuario(usuarioDTO.getPkUsuario());
            usuario.setFkPessoa(pessoa);
            usuario.setEmail(usuarioDTO.getEmail());
            usuario.setSenha(usuarioDTO.getSenha());
            usuario.setTipo(TipoUsuario.fromValor(usuarioDTO.getTipo()));
            usuario.setFkEmpresa(empresa.get());

            return Optional.of(usuario);
        }
        return Optional.empty();
    }

    public UsuarioDTO toDTO(Usuario usuario){
        UsuarioDTO usuarioDTO = new UsuarioDTO();

        usuarioDTO.setPkUsuario(usuario.getPkUsuario());
        usuarioDTO.setNome(usuario.getFkPessoa().getNome());
        usuarioDTO.setEmail(usuario.getEmail());
        usuarioDTO.setSenha(usuario.getSenha());
        usuarioDTO.setTipo(usuario.getTipo().getValor());
        usuarioDTO.setSexo(usuario.getFkPessoa().getSexo().getValor());
        usuarioDTO.setTelefone(usuario.getFkPessoa().getFkContacto().getTelefone());
        usuarioDTO.setFkLocalidade(usuario.getFkPessoa().getFkLocalidade().getPkLocalidade());
        usuarioDTO.setFkEmpresa(usuario.getFkEmpresa().getPkEmpresa());

        return usuarioDTO;
    }
}
