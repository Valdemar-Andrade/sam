package com.ucan.sam.controllers;

import com.ucan.sam.entities.DTO.EmpresaDTO;
import com.ucan.sam.entities.Empresa;
import com.ucan.sam.mapper.EmpresaMapper;
import com.ucan.sam.security.AuthUtil;
import com.ucan.sam.services.EmpresaService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/empresa")
public class EmpresaController
{
    @Autowired
    private EmpresaService empresaService;

    @Autowired
    private EmpresaMapper empresaMapper;

    @PostMapping
    public ResponseEntity<?> criarEmpresa(@RequestBody EmpresaDTO empresaDTO, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForAdmin(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Empresa> empresaSalva = empresaService.criarEmpresa(empresaDTO);

            if (empresaSalva.isPresent()){
                return ResponseEntity.ok(empresaMapper.toDTO(empresaSalva.get()));
            }
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erro ao criar a Empresa!");
        }else {
            return auth;
        }
    }

    @GetMapping
    public ResponseEntity<?> findAll(HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForAdmin(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            List<Empresa> empresas = empresaService.findAll();

            if (empresas.isEmpty()){
                return ResponseEntity.noContent().build();
            }else {
                List<EmpresaDTO> empresasDTO = new ArrayList<>();
                for (Empresa empresa: empresas){
                    empresasDTO.add(empresaMapper.toDTO(empresa));
                }
                return ResponseEntity.ok(empresasDTO);
            }
        }else {
            return auth;
        }

    }

    @GetMapping("/{pk}")
    public ResponseEntity<?> findByPk(@PathVariable Integer pk, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForAdmin(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Empresa> empresa = empresaService.findByPk(pk);

            if (empresa.isPresent())
                return ResponseEntity.ok(empresaMapper.toDTO(empresa.get()));
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Empresa não encontrada!");
        }else {
            return auth;
        }
    }

    @PutMapping
    public ResponseEntity<?> updateEmpresa(@RequestBody EmpresaDTO empresaDTO, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForAdmin(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){
            Optional<Empresa> empresaAtualizada = empresaService.updateEmpresa(empresaDTO);

            if (empresaAtualizada.isPresent()){
                return ResponseEntity.ok(empresaMapper.toDTO(empresaAtualizada.get()));
            }else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Empresa não encontrada!");
            }
        }else {
            return auth;
        }
    }

    @DeleteMapping("/{pk}")
    public ResponseEntity<?> deleteEmpresa(@PathVariable Integer pk, HttpSession session){
        ResponseEntity<?> auth = AuthUtil.authAndAccessForAdmin(session);
        if (auth.getStatusCode().isSameCodeAs(HttpStatus.OK)){

            if (empresaService.delete(pk)){
                return ResponseEntity.ok("Empresa Deletada com sucesso!");
            }else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Empresa não encontrada!");
            }
        }else {
            return auth;
        }
    }
}
