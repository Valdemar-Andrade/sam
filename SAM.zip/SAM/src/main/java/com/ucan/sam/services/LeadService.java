package com.ucan.sam.services;

import com.ucan.sam.entities.*;
import com.ucan.sam.entities.DTO.LeadDTO;
import com.ucan.sam.enums.Sexo;
import com.ucan.sam.mapper.LeadMapper;
import com.ucan.sam.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import java.util.Optional;

@Service
public class LeadService
{
    @Autowired
    private LeadRepository leadRepository;
    @Autowired
    private EmpresaRepository empresaRepository;
    @Autowired
    private TopicoRepository topicoRepository;
    @Autowired
    private ContactoService contactoService;
    @Autowired
    private LocalidadeRepository localidadeRepository;
    @Autowired
    private PessoaService pessoaService;
    @Autowired
    private TopicoService topicoService;
    @Autowired
    private ContactoRepository contactoRepository;
    @Autowired
    private LeadMapper leadMapper;
    @Autowired
    private PessoaRepository pessoaRepository;

    public Optional<Lead> criarLead(LeadDTO leadDTO) {

        Optional<Localidade> localidade = localidadeRepository.findById(leadDTO.getFkLocalidade());
        Optional<Empresa> empresa = empresaRepository.findById(leadDTO.getFkEmpresa());
        List<Topico> topicosInteresse = topicoService.getEntityByPkList(leadDTO.getTopicosInteresse());

        if (localidade.isPresent() && empresa.isPresent() && !topicosInteresse.isEmpty()){
            Contacto contacto = new Contacto();
            contacto.setTelefone(leadDTO.getTelefone());
            contacto.setEmail(leadDTO.getEmail());
            Contacto contactoSalvo = contactoService.cadastrarContacto(contacto);

            Pessoa pessoa = new Pessoa();
            pessoa.setFkContacto(contactoSalvo);
            pessoa.setNome(leadDTO.getNome());
            pessoa.setSexo(Sexo.fromValor(leadDTO.getSexo()));
            pessoa.setFkLocalidade(localidade.get());
            Pessoa pessoaSalva = pessoaService.cadastrarPessoa(pessoa);

            Lead lead = new Lead();
            lead.setFkPessoa(pessoaSalva);
            lead.setFkEmpresa(List.of(empresa.get()));
            lead.setTopicosInteresse(topicosInteresse);

            Lead leadSalvo = leadRepository.save(lead);
            if (leadSalvo.getPkLead() == null){
                rollBackLead(pessoaSalva, contactoSalvo);
            }

            return Optional.of(leadSalvo);
        }else {
            return Optional.empty();
        }
    }

    public List<Lead> listarLeads() {
        return leadRepository.findAll();
    }

    private String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString(); // Se for uma data
                } else {
                    return String.valueOf((long) cell.getNumericCellValue()); // Converte para inteiro se for numérico
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            default:
                return "";
        }
    }

    private Integer getCellValueAsInteger(Cell cell) {
        if (cell == null) return null;
        try {
            return (int) cell.getNumericCellValue();
        } catch (Exception e) {
            return null;
        }
    }

    public boolean processarExcel(MultipartFile file, Integer empresaPk){
        Optional<Empresa> empresa = empresaRepository.findById(empresaPk);
        if (empresa.isEmpty()){
            return false;
        }

        // Abre o arquivo Excel
        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            // Obtem a primeira planilha
            Sheet sheet = workbook.getSheetAt(0);

            // Itera pelas linhas (começando na linha 1 para ignorar o cabeçalho)
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                // Cria um Lead
                Lead lead = new Lead();
                Contacto contacto = new Contacto();
                contacto.setEmail(getCellValueAsString(row.getCell(1)));
                contacto.setTelefone(getCellValueAsString(row.getCell(2)));
                Contacto contactoSalvo = contactoService.cadastrarContacto(contacto);

                Pessoa pessoa = new Pessoa();
                pessoa.setFkContacto(contactoSalvo);
                pessoa.setNome(getCellValueAsString(row.getCell(0)));

                String sexo = getCellValueAsString(row.getCell(3));
                if (sexo.equalsIgnoreCase("M")){
                    pessoa.setSexo(Sexo.MASCULINO);
                }
                if (sexo.equalsIgnoreCase("F")){
                    pessoa.setSexo(Sexo.FEMININO);
                }

                Localidade localidade = localidadeRepository.findById(getCellValueAsInteger(row.getCell(4))).get();
                pessoa.setFkLocalidade(localidade);
                Pessoa pessoaSalva = pessoaService.cadastrarPessoa(pessoa);

                lead.setFkPessoa(pessoaSalva);
                lead.setFkEmpresa(List.of(empresa.get()));

                // Processa os tópicos de interesse
                String topicosStr = getCellValueAsString(row.getCell(5)); // Tópicos em uma célula
                String[] topicos = topicosStr.split(",");
                List<Topico> topicosInteresse = new ArrayList<>();

                for (String topicoNome : topicos) {
                    Topico topico = topicoRepository.findByNome(topicoNome.trim())
                            .orElseGet(() -> {
                                // Cria um novo tópico se não existir
                                Topico novoTopico = new Topico();
                                novoTopico.setNome(topicoNome.trim());
                                novoTopico.setDescricao(" ");
                                return topicoRepository.save(novoTopico);
                            });
                    topicosInteresse.add(topico);
                }

                lead.setTopicosInteresse(topicosInteresse);
                Lead leadSalvo = leadRepository.save(lead);
                if (leadSalvo.getPkLead() == null){
                    rollBackLead(pessoaSalva, contactoSalvo);
                    return false;
                }
            }
        } catch (IOException e)
        {
            throw new RuntimeException(e);
        }
        return true;
        // Salva todos os leads no banco
        //leadRepository.saveAll(leads);
    }

    private void rollBackLead(Pessoa pessoaSalva, Contacto contactoSalvo)
    {
        pessoaRepository.deleteById(pessoaSalva.getPkPessoa());
        contactoRepository.deleteById(contactoSalvo.getPkContacto());
    }

    public Optional<Lead> findByPk(Integer pk){
        return leadRepository.findById(pk);
    }

    public Optional<Lead> updateLead(LeadDTO leadDTO)
    {
        Optional<Lead> lead = leadRepository.findById(leadDTO.getPkLead());
        Optional<Localidade> localidade = localidadeRepository.findById(leadDTO.getFkLocalidade());
        Optional<Empresa> empresa = empresaRepository.findById(leadDTO.getFkEmpresa());

        if (lead.isPresent() && localidade.isPresent() && empresa.isPresent()){
            Contacto contacto = lead.get().getFkPessoa().getFkContacto();
            contacto.setTelefone(leadDTO.getTelefone());
            contacto.setEmail(leadDTO.getEmail());

            Pessoa pessoa = lead.get().getFkPessoa();
            pessoa.setSexo(Sexo.fromValor(leadDTO.getSexo()));
            pessoa.setNome(leadDTO.getNome());
            pessoa.setFkContacto(contacto);
            pessoa.setFkLocalidade(localidade.get());

            lead.get().setFkPessoa(pessoa);
            lead.get().setFkEmpresa(List.of(empresa.get()));
            lead.get().setTopicosInteresse(topicoService.getEntityByPkList(leadDTO.getTopicosInteresse()));

            return Optional.of(leadRepository.save(lead.get()));
        }else {
            return Optional.empty();
        }
    }

    public Optional<Lead> delete(Integer pk){
        Optional<Lead> lead = leadRepository.findById(pk);
        if (lead.isPresent()){
            leadRepository.deleteById(pk);
            return lead;
        }else {
            return Optional.empty();
        }
    }
}
