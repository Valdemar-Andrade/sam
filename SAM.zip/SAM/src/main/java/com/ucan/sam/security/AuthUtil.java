package com.ucan.sam.security;

import com.ucan.sam.entities.Usuario;
import com.ucan.sam.enums.TipoUsuario;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class AuthUtil
{
    public static boolean isUserAuthenticated(HttpSession session) {
        return session.getAttribute("usuarioLogado") != null;
    }

    public static boolean isUserAdmin(HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
        return usuario != null && usuario.getTipo() == TipoUsuario.ADMINISTRADOR;
    }

    public static boolean isUser(HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
        return usuario != null && usuario.getTipo() == TipoUsuario.USUARIO_FINAL;
    }

    /**
     * Autentica e valida se o Login realizado tem privilegio de Admin
     *
     */
    public static ResponseEntity<?> authAndAccessForAdmin(HttpSession session){
        if (!AuthUtil.isUserAuthenticated(session)){
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Usuário não autenticado");
        }

        if (AuthUtil.isUserAdmin(session)){
            return ResponseEntity.ok("Usuário autenticado!");
        }else {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Acesso negado.");
        }
    }

    /**
     * Autentica e valida se o Login realizado tem privilegio de Usuario
     *
     */
    public static ResponseEntity<?> authAndAccessForUser(HttpSession session){
        if (!AuthUtil.isUserAuthenticated(session)){
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Usuário não autenticado");
        }

        if (AuthUtil.isUser(session)){
            return ResponseEntity.ok("Usuário autenticado!");
        }else {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Acesso negado.");
        }
    }
}
